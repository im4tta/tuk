import pyperclip
from PyQt6.QtCore import QThread, pyqtSignal
from datetime import datetime


class ClipboardMonitor(QThread):
    clipboard_changed = pyqtSignal(str)
    
    def __init__(self):
        super().__init__()
        self.running = True
        self.last_value = ""
        
    def run(self):
        while self.running:
            try:
                current = pyperclip.paste()
                if current != self.last_value and current.strip():
                    self.last_value = current
                    self.clipboard_changed.emit(current)
            except Exception as e:
                print(f"Error monitoring clipboard: {e}")
            self.msleep(500)
    
    def stop(self):
        self.running = False


class ClipboardItem:
    def __init__(self, content):
        self.content = content
        self.timestamp = datetime.now()
        self.pinned = False
    
    def __str__(self):
        preview = self.content[:50] + "..." if len(self.content) > 50 else self.content
        return preview.replace('\n', ' ')

import sys
import os
import pyperclip
import time
import json
from PyQt6.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, 
                             QHBoxLayout, QPushButton, QTextEdit, QListWidget, 
                             QLabel, QCheckBox, QComboBox, QLineEdit, QTabWidget,
                             QListWidgetItem, QMessageBox)
from PyQt6.QtCore import Qt, QTimer, QSettings
from PyQt6.QtGui import QFont, QIcon, QFontDatabase
from clipboard_manager import ClipboardMonitor, ClipboardItem


class ClipboardApp(QMainWindow):
    def __init__(self):
        super().__init__()
        self.history = []
        self.pinned = []
        self.undo_stack = []
        self.redo_stack = []
        self.auto_paste = False
        self.settings = QSettings("ClipboardManager", "Settings")
        self.load_settings()
        self.monitor = ClipboardMonitor()
        self.monitor.clipboard_changed.connect(self.on_clipboard_change)
        self.init_ui()
        self.apply_saved_settings()
        self.monitor.start()
    
    def init_ui(self):
        self.setWindowTitle("Clipboard Manager (Khmer)")
        self.setGeometry(100, 100, 1000, 650)
        
        # Determine base path for resources
        if getattr(sys, 'frozen', False):
            # Running as compiled exe
            base_path = sys._MEIPASS
        else:
            # Running as script
            base_path = os.path.dirname(os.path.abspath(__file__))
        
        # Set window icon
        icon_path = os.path.join(base_path, "app_icon.ico")
        if os.path.exists(icon_path):
            self.setWindowIcon(QIcon(icon_path))
            print(f"✓ Loaded icon: {icon_path}")
        
        # Load bundled Khmer font
        font_loaded = False
        
        font_path = os.path.join(base_path, "NotoSansKhmer.ttf")
        if os.path.exists(font_path):
            font_id = QFontDatabase.addApplicationFont(font_path)
            if font_id != -1:
                font_families = QFontDatabase.applicationFontFamilies(font_id)
                if font_families:
                    khmer_font = QFont(font_families[0], 11)
                    QApplication.setFont(khmer_font)
                    font_loaded = True
                    print(f"✓ Loaded font: {font_families[0]}")
        
        if not font_loaded:
            # Fallback to system Khmer fonts
            for font_name in ["Noto Sans Khmer", "Khmer OS", "Khmer OS System", "Leelawadee UI"]:
                khmer_font = QFont(font_name, 11)
                if khmer_font.family() == font_name:
                    QApplication.setFont(khmer_font)
                    print(f"✓ Using system font: {font_name}")
                    break
        
        self.setStyleSheet("""
            QMainWindow {
                background-color: #1e1e2e;
            }
            QWidget {
                background-color: #1e1e2e;
                color: #cdd6f4;
                font-family: 'Noto Sans Khmer', 'Khmer OS', 'Leelawadee UI', 'Segoe UI', Arial;
                font-size: 11pt;
            }
            QPushButton {
                background-color: #313244;
                border: 1px solid #45475a;
                border-radius: 6px;
                padding: 8px 16px;
                color: #cdd6f4;
            }
            QPushButton:hover {
                background-color: #45475a;
            }
            QPushButton#clearBtn {
                background-color: #f38ba8;
                color: #1e1e2e;
                font-weight: bold;
            }
            QPushButton#clearBtn:hover {
                background-color: #eba0ac;
            }
            QTextEdit, QLineEdit {
                background-color: #181825;
                border: 1px solid #45475a;
                border-radius: 6px;
                padding: 8px;
                color: #cdd6f4;
            }
            QListWidget {
                background-color: #181825;
                border: 1px solid #45475a;
                border-radius: 6px;
                padding: 4px;
            }
            QListWidget::item {
                padding: 8px;
                border-radius: 4px;
            }
            QListWidget::item:selected {
                background-color: #313244;
            }
            QListWidget::item:hover {
                background-color: #45475a;
            }
            QCheckBox {
                spacing: 8px;
            }
            QCheckBox::indicator {
                width: 18px;
                height: 18px;
                border-radius: 4px;
                border: 2px solid #45475a;
                background-color: #181825;
            }
            QCheckBox::indicator:checked {
                background-color: #89b4fa;
                border-color: #89b4fa;
            }
            QComboBox {
                background-color: #313244;
                border: 1px solid #45475a;
                border-radius: 6px;
                padding: 6px;
            }
            QComboBox::drop-down {
                border: none;
            }
            QComboBox::down-arrow {
                image: none;
                border-left: 4px solid transparent;
                border-right: 4px solid transparent;
                border-top: 6px solid #cdd6f4;
            }
            QTabWidget::pane {
                border: 1px solid #45475a;
                border-radius: 6px;
                background-color: #181825;
            }
            QTabBar::tab {
                background-color: #313244;
                color: #cdd6f4;
                padding: 8px 16px;
                border-top-left-radius: 6px;
                border-top-right-radius: 6px;
                margin-right: 2px;
            }
            QTabBar::tab:selected {
                background-color: #181825;
            }
        """)
        
        central = QWidget()
        self.setCentralWidget(central)
        main_layout = QVBoxLayout(central)
        main_layout.setSpacing(12)
        main_layout.setContentsMargins(16, 16, 16, 16)
        
        # Header
        header = QHBoxLayout()
        title = QLabel("📋 កម្មវិធីគ្រប់គ្រង\nClipboard")
        title.setStyleSheet("font-size: 14pt; font-weight: bold; color: #a6e3a1; font-family: 'Noto Sans Khmer', 'Khmer OS';")
        header.addWidget(title)
        
        self.auto_paste_cb = QCheckBox("បិទបើក\nស្វ័យប្រវត្តិ")
        self.auto_paste_cb.setStyleSheet("font-family: 'Noto Sans Khmer', 'Khmer OS';")
        self.auto_paste_cb.stateChanged.connect(self.toggle_auto_paste)
        header.addWidget(self.auto_paste_cb)
        
        self.separator_combo = QComboBox()
        self.separator_combo.setStyleSheet("font-family: 'Noto Sans Khmer', 'Khmer OS';")
        self.separator_combo.addItems(["មួយជួរ (New Line)", ", (Comma)", "  (Space)", "⇥ (Tab)"])
        self.separator_combo.setMinimumWidth(150)
        header.addWidget(self.separator_combo)
        
        undo_btn = QPushButton("Undo")
        undo_btn.clicked.connect(self.undo)
        header.addWidget(undo_btn)
        
        redo_btn = QPushButton("Redo")
        redo_btn.clicked.connect(self.redo)
        header.addWidget(redo_btn)
        
        copy_all_btn = QPushButton("ចម្លង\nទាំងអស់")
        copy_all_btn.setStyleSheet("font-family: 'Noto Sans Khmer', 'Khmer OS';")
        copy_all_btn.clicked.connect(self.copy_all)
        header.addWidget(copy_all_btn)
        
        paste_btn = QPushButton("បិទភ្ជាប់")
        paste_btn.setStyleSheet("font-family: 'Noto Sans Khmer', 'Khmer OS';")
        paste_btn.clicked.connect(self.paste_content)
        header.addWidget(paste_btn)
        
        clear_btn = QPushButton("លុប\nទាំងអស់")
        clear_btn.setObjectName("clearBtn")
        clear_btn.setStyleSheet("background-color: #f38ba8; color: #1e1e2e; font-weight: bold; font-family: 'Noto Sans Khmer', 'Khmer OS';")
        clear_btn.clicked.connect(self.clear_all)
        header.addWidget(clear_btn)
        
        about_btn = QPushButton("អំពី")
        about_btn.setStyleSheet("font-family: 'Noto Sans Khmer', 'Khmer OS';")
        about_btn.clicked.connect(self.show_about)
        header.addWidget(about_btn)
        
        main_layout.addLayout(header)
        
        # Content area
        content = QHBoxLayout()
        
        # Left panel
        left_panel = QVBoxLayout()
        
        sep_label = QLabel("ជ្រើសរើស Separator ពីខាងលើ ហើយប្រើ Split/Merge")
        sep_label.setStyleSheet("font-size: 9pt; color: #7f849c; font-family: 'Noto Sans Khmer', 'Khmer OS';")
        left_panel.addWidget(sep_label)
        
        btn_row = QHBoxLayout()
        split_btn = QPushButton("បំបែក")
        split_btn.setStyleSheet("font-family: 'Noto Sans Khmer', 'Khmer OS';")
        split_btn.clicked.connect(self.split_text)
        btn_row.addWidget(split_btn)
        
        merge_btn = QPushButton("បញ្ចូលគ្នា")
        merge_btn.setStyleSheet("font-family: 'Noto Sans Khmer', 'Khmer OS';")
        merge_btn.clicked.connect(self.merge_text)
        btn_row.addWidget(merge_btn)
        left_panel.addLayout(btn_row)
        
        self.text_area = QTextEdit()
        self.text_area.setPlaceholderText("ទិន្នន័យដែល : \n១២៣៤៥៦៧\nទីនេះ\nសម្រាប់...")
        self.text_area.setStyleSheet("font-family: 'Noto Sans Khmer', 'Khmer OS';")
        left_panel.addWidget(self.text_area)
        
        help_label = QLabel("បំបែក: ប្រើ separator ដើម្បីបំបែកជាបន្ទាត់ថ្មី។ បញ្ចូលគ្នា: បញ្ចូលបន្ទាត់ដោយប្រើ separator ដែលបានជ្រើសរើស។")
        help_label.setStyleSheet("font-size: 9pt; color: #7f849c; font-family: 'Noto Sans Khmer', 'Khmer OS';")
        help_label.setWordWrap(True)
        left_panel.addWidget(help_label)
        
        content.addLayout(left_panel, 3)
        
        # Right panel
        right_panel = QVBoxLayout()
        
        self.tabs = QTabWidget()
        
        # Pinned tab
        self.pinned_list = QListWidget()
        self.pinned_list.setStyleSheet("font-family: 'Noto Sans Khmer', 'Khmer OS';")
        self.pinned_list.itemDoubleClicked.connect(self.copy_item)
        self.tabs.addTab(self.pinned_list, "ភ្ជាប់រហូត")
        
        # History tab
        self.history_list = QListWidget()
        self.history_list.setStyleSheet("font-family: 'Noto Sans Khmer', 'Khmer OS';")
        self.history_list.itemDoubleClicked.connect(self.copy_item)
        self.history_list.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.history_list.customContextMenuRequested.connect(self.show_context_menu)
        self.tabs.addTab(self.history_list, "ប្រវត្តិ")
        
        right_panel.addWidget(self.tabs)
        content.addLayout(right_panel, 2)
        
        main_layout.addLayout(content)
        
        # Footer
        footer_layout = QHBoxLayout()
        footer = QLabel("Font: Noto Sans Khmer · Clipboard Manager")
        footer.setStyleSheet("color: #7f849c; font-size: 9pt; font-family: 'Noto Sans Khmer', 'Khmer OS';")
        footer_layout.addWidget(footer)
        
        footer_layout.addStretch()
        
        contact = QLabel('<a href="https://t.me/tmeta9" style="color: #89b4fa; text-decoration: none;">Contact: t.me/tmeta9</a>')
        contact.setOpenExternalLinks(True)
        contact.setStyleSheet("font-size: 9pt;")
        footer_layout.addWidget(contact)
        
        main_layout.addLayout(footer_layout)
    
    def toggle_auto_paste(self, state):
        self.auto_paste = state == Qt.CheckState.Checked.value
        self.save_settings()
    
    def on_clipboard_change(self, content):
        if content and content not in [item.content for item in self.history]:
            item = ClipboardItem(content)
            self.history.insert(0, item)
            self.update_history_list()
            if len(self.history) > 100:
                self.history.pop()
            
            # Auto-paste if enabled - paste to text area
            if self.auto_paste:
                current_text = self.text_area.toPlainText()
                if current_text:
                    # Append with separator
                    sep = self.get_separator()
                    new_text = current_text + sep + content
                    self.text_area.setPlainText(new_text)
                else:
                    # First item
                    self.text_area.setPlainText(content)
    
    def update_history_list(self):
        self.history_list.clear()
        for item in self.history:
            self.history_list.addItem(str(item))
    
    def update_pinned_list(self):
        self.pinned_list.clear()
        for item in self.pinned:
            self.pinned_list.addItem(str(item))
    
    def copy_item(self, item):
        idx = self.history_list.row(item) if self.tabs.currentIndex() == 1 else self.pinned_list.row(item)
        items = self.history if self.tabs.currentIndex() == 1 else self.pinned
        if 0 <= idx < len(items):
            pyperclip.copy(items[idx].content)
    
    def show_context_menu(self, pos):
        item = self.history_list.itemAt(pos)
        if item:
            idx = self.history_list.row(item)
            if 0 <= idx < len(self.history):
                if not self.history[idx].pinned:
                    self.history[idx].pinned = True
                    self.pinned.append(self.history[idx])
                    self.update_pinned_list()
    
    def split_text(self):
        text = self.text_area.toPlainText()
        sep = self.get_separator()
        if sep and text:
            self.undo_stack.append(text)
            self.redo_stack.clear()
            result = text.replace(sep, '\n')
            self.text_area.setPlainText(result)
    
    def merge_text(self):
        text = self.text_area.toPlainText()
        sep = self.get_separator()
        if text:
            self.undo_stack.append(text)
            self.redo_stack.clear()
            lines = [line.strip() for line in text.split('\n') if line.strip()]
            result = sep.join(lines)
            self.text_area.setPlainText(result)
    
    def get_separator(self):
        idx = self.separator_combo.currentIndex()
        if idx == 0:
            return '\n'
        elif idx == 1:
            return ', '
        elif idx == 2:
            return ' '
        elif idx == 3:
            return '\t'
        return '\n'
    
    def undo(self):
        if self.undo_stack:
            current = self.text_area.toPlainText()
            self.redo_stack.append(current)
            self.text_area.setPlainText(self.undo_stack.pop())
    
    def redo(self):
        if self.redo_stack:
            current = self.text_area.toPlainText()
            self.undo_stack.append(current)
            self.text_area.setPlainText(self.redo_stack.pop())
    
    def copy_all(self):
        text = self.text_area.toPlainText()
        if text:
            pyperclip.copy(text)
    
    def paste_content(self):
        try:
            content = pyperclip.paste()
            self.text_area.setPlainText(content)
        except:
            pass
    
    def clear_all(self):
        reply = QMessageBox.question(self, 'លុបទាំងអស់', 
                                     'តើអ្នកចង់លុបប្រវត្តិទាំងអស់មែនទេ?',
                                     QMessageBox.StandardButton.Yes | 
                                     QMessageBox.StandardButton.No)
        if reply == QMessageBox.StandardButton.Yes:
            self.history.clear()
            self.update_history_list()
            self.text_area.clear()
    
    def show_about(self):
        QMessageBox.about(self, "អំពីកម្មវិធី", 
                         "កម្មវិធីគ្រប់គ្រង Clipboard\nកំណែ 1.0\n\n"
                         "កម្មវិធីគ្រប់គ្រង clipboard ដែលមានមុខងារបំបែក និងបញ្ចូលគ្នា។\n\n"
                         "ទំនាក់ទំនង: t.me/tmeta9")
    
    def save_settings(self):
        self.settings.setValue("auto_paste", self.auto_paste)
        self.settings.setValue("separator_index", self.separator_combo.currentIndex())
    
    def load_settings(self):
        self.auto_paste = self.settings.value("auto_paste", False, type=bool)
        self.saved_separator_index = self.settings.value("separator_index", 0, type=int)
    
    def apply_saved_settings(self):
        self.auto_paste_cb.setChecked(self.auto_paste)
        self.separator_combo.setCurrentIndex(self.saved_separator_index)
        # Connect change handlers
        self.separator_combo.currentIndexChanged.connect(self.save_settings)
    
    def closeEvent(self, event):
        self.save_settings()
        self.monitor.stop()
        self.monitor.wait()
        event.accept()


if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = ClipboardApp()
    window.show()
    sys.exit(app.exec())

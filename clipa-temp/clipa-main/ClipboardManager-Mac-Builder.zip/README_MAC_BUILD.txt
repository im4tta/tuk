# ClipboardManager - Mac Build Instructions

## Quick Setup (5 minutes):

1. **Extract this ZIP** to any folder on your Mac
2. **Open Terminal** and navigate to the folder:
   ```bash
   cd /path/to/extracted/folder
   ```
3. **Run the build script**:
   ```bash
   python3 build_simple_mac.py
   ```
4. **Install the DMG** that gets created

## What This Does:
- Installs PyInstaller automatically
- Builds a native macOS app
- Creates a DMG installer
- Ready to install on any Mac (Intel or Apple Silicon)

## Requirements:
- macOS (any version with Python 3.6+)
- Internet connection (for PyInstaller download)

## Troubleshooting:
If you get permission errors, run:
```bash
chmod +x build_simple_mac.py
python3 build_simple_mac.py
```

That's it! The script handles everything else automatically.
